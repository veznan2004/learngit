#ifndef __EXFUNC_H__
#define __EXFUNC_H__

#include <stdio.h>
#include <stdlib.h>
#include "main.h"

void reverse_list(linklist he);
void parity_list(linklist he);

void tectonic_cycle(linklist he);

void jud_cycle(linklist he);


#endif
