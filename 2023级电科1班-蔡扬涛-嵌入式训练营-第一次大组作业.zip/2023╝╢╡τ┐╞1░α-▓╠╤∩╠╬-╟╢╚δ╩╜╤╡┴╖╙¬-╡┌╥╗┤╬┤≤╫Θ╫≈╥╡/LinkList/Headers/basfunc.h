#ifndef __BASFUNC_H__
#define __BASFUNC_H__

#include <stdio.h>
#include <stdlib.h>
#include "main.h"


ln* list_create(int num);
void list_dis(linklist he);
int list_delete(linklist he);
int query_list(linklist he);
void delete_node(linklist he);
void add_node(linklist he);

#endif