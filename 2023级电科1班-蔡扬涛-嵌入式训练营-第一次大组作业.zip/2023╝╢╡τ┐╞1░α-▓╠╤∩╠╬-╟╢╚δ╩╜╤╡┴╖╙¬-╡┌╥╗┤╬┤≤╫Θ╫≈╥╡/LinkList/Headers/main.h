#ifndef __main_h__
#define __main_h__

typedef struct ln
{
	int data;
	struct ln* next;

} ln, * linklist;



#define length sizeof(ln)

#endif
